import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Curso, CursoRequest } from '../models/curso.model';
import { API_URL } from './api.config';

@Injectable({
  providedIn: 'root'
})
export class CursoService {

  private readonly http = inject(HttpClient);

  listarCursos(): Observable<Curso[]> {
    return this.http.get<Curso[]>(
      `${API_URL}/cursos`
    );
  }

  crearCurso(request: CursoRequest): Observable<Curso> {
    return this.http.post<Curso>(
      `${API_URL}/cursos`,
      request
    );
  }
}