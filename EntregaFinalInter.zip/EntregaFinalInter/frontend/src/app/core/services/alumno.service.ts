import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Curso } from '../models/curso.model';
import { Nota } from '../models/nota.model';
import { API_URL } from './api.config';

@Injectable({
  providedIn: 'root'
})
export class AlumnoService {

  private readonly http = inject(HttpClient);
  private readonly apiUrl = `${API_URL}/alumno`;

  misCursos(): Observable<Curso[]> {
    return this.http.get<Curso[]>(
      `${this.apiUrl}/mis-cursos`
    );
  }

  misNotas(): Observable<Nota[]> {
    return this.http.get<Nota[]>(
      `${API_URL}/notas/mis-notas`
    );
  }
}