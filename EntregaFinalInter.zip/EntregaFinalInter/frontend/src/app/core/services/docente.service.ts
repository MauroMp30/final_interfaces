import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Curso } from '../models/curso.model';
import { Alumno } from '../models/alumno.model';
import {
  Nota,
  NotaRequest
} from '../models/nota.model';
import { API_URL } from './api.config';

@Injectable({
  providedIn: 'root'
})
export class DocenteService {

  private readonly http = inject(HttpClient);
  private readonly apiUrl = `${API_URL}/docente`;

  misCursos(): Observable<Curso[]> {
    return this.http.get<Curso[]>(
      `${this.apiUrl}/mis-cursos`
    );
  }

  alumnosPorCurso(idCurso: number): Observable<Alumno[]> {
    return this.http.get<Alumno[]>(
      `${this.apiUrl}/curso/${idCurso}/alumnos`
    );
  }

  registrarNota(request: NotaRequest): Observable<Nota> {
    return this.http.post<Nota>(
      `${API_URL}/notas`,
      request
    );
  }

  notasPorCurso(idCurso: number): Observable<Nota[]> {
    return this.http.get<Nota[]>(
      `${API_URL}/notas/curso/${idCurso}`
    );
  }
}