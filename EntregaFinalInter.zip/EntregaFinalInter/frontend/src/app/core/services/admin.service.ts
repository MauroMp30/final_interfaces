import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Usuario } from '../models/usuario.model';
import { Alumno } from '../models/alumno.model';
import { Docente } from '../models/docente.model';
import { Seccion } from '../models/seccion.model';
import {
  Asignacion,
  AsignacionRequest
} from '../models/asignacion.model';
import {
  Matricula,
  MatriculaRequest
} from '../models/matricula.model';
import { API_URL } from './api.config';

export interface UsuarioRequest {
  username: string;
  password: string;
  dni: string;
  nombre: string;
  apellido: string;
  email: string;
  rol: 'ADMIN' | 'DOCENTE' | 'ESTUDIANTE';

  especialidad?: string;
  gradoAcademico?: string;
  telefono?: string;
  dniApoderado?: string;
  fechaNacimiento?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  crearUsuario(request: UsuarioRequest): Observable<Usuario> {
  return this.http.post<Usuario>(
    `${this.apiUrl}/usuarios`,
    request
  );
}

  private readonly http = inject(HttpClient);
  private readonly apiUrl = `${API_URL}/admin`;

  listarUsuarios(): Observable<Usuario[]> {
    return this.http.get<Usuario[]>(
      `${this.apiUrl}/usuarios`
    );
  }

  listarDocentes(): Observable<Docente[]> {
    return this.http.get<Docente[]>(
      `${this.apiUrl}/docentes`
    );
  }

  listarAlumnos(): Observable<Alumno[]> {
    return this.http.get<Alumno[]>(
      `${this.apiUrl}/alumnos`
    );
  }

  listarSecciones(): Observable<Seccion[]> {
    return this.http.get<Seccion[]>(
      `${this.apiUrl}/secciones`
    );
  }

  listarAsignaciones(): Observable<Asignacion[]> {
    return this.http.get<Asignacion[]>(
      `${this.apiUrl}/asignaciones`
    );
  }


  asignarCurso(
    request: AsignacionRequest
  ): Observable<Asignacion> {
    return this.http.post<Asignacion>(
      `${this.apiUrl}/asignaciones`,
      request
    );
  }

  listarMatriculas(): Observable<Matricula[]> {
    return this.http.get<Matricula[]>(
      `${this.apiUrl}/matriculas`
    );
  }

  matricularAlumno(
    request: MatriculaRequest
  ): Observable<Matricula> {
    return this.http.post<Matricula>(
      `${this.apiUrl}/matriculas`,
      request
    );
  }
  crearAsignacion(
  request: AsignacionRequest
): Observable<Asignacion> {

  return this.http.post<Asignacion>(
    `${API_URL}/admin/asignaciones`,
    request
  );
}

crearMatricula(
  request: MatriculaRequest
): Observable<Matricula> {

  return this.http.post<Matricula>(
    `${API_URL}/admin/matriculas`,
    request
  );
}
}