export interface Curso {
  idCurso: number;
  nombre: string;
  descripcion: string;
  creditos: number;
  estado: boolean;
  seccion: string | null;
}

export interface CursoRequest {
  nombre: string;
  descripcion: string;
  creditos: number;
  idSeccion?: number | null;
}