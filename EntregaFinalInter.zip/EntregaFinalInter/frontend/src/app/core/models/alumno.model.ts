export interface Alumno {
  idAlumno: number;
  username: string;
  nombreCompleto: string;
  dniApoderado: string;
  telefono: string;
  fechaNacimiento: string;
}