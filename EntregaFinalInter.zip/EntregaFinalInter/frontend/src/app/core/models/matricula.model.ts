export interface Matricula {
  idMatricula: number;
  alumno: string;
  seccion: string;
  fechaMatricula: string;
  estado: boolean;
}

export interface MatriculaRequest {
  idAlumno: number;
  idSeccion: number;
}