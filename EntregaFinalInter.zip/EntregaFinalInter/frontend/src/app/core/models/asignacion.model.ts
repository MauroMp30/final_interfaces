export interface Asignacion {
  idAsignacion: number;
  docente: string;
  curso: string;
  estado: boolean;
  fechaAsignacion: string;
}

export interface AsignacionRequest {
  idDocente: number;
  idCurso: number;
}