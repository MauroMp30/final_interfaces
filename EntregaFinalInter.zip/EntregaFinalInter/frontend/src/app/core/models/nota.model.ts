export interface Nota {
  idNota: number;
  curso: string;
  alumno: string;
  nombreEvaluacion: string;
  calificacion: number;
  ponderacion: number;
}

export interface NotaRequest {
  idCurso: number;
  idAlumno: number;
  nombreEvaluacion: string;
  calificacion: number;
  ponderacion: number;
}