export interface Usuario {
  idUsuario: number;
  username: string;
  dni: string;
  nombre: string;
  apellido: string;
  email: string;
  rol: string;
  estado: boolean;
}