export interface Seccion {
  idSeccion: number;
  nombreSeccion: string;
  periodoAcademico: string;
  capacidadMaxima: number;
  estado: boolean;
}