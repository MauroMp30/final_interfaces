export interface Docente {
  idDocente: number;
  username: string;
  nombreCompleto: string;
  especialidad: string;
  gradoAcademico: string;
  telefono: string;
}