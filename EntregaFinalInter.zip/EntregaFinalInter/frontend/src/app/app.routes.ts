import { Routes } from '@angular/router';

import { LoginComponent } from './features/auth/login/login';
import { AdminComponent } from './features/admin/admin';
import { DocenteComponent } from './features/docente/docente';
import { AlumnoComponent } from './features/alumno/alumno';
import { authGuard } from './core/guards/auth.guard';
import { UsuariosComponent } from './features/admin/usuarios/usuarios';
import { DocentesComponent } from './features/admin/docentes/docentes';
import { AlumnosComponent } from './features/admin/alumnos/alumnos';
import { CursosComponent } from './features/admin/cursos/cursos';
import { SeccionesComponent } from './features/admin/secciones/secciones';
import { AsignacionesComponent } from './features/admin/asignaciones/asignaciones';
import { MatriculasComponent } from './features/admin/matriculas/matriculas';
import { CursoDetalleComponent } from './features/docente/curso-detalle/curso-detalle';
import { RegistrarNotaComponent } from './features/docente/registrar-nota/registrar-nota';
import { NotasCursoComponent } from './features/docente/notas-curso/notas-curso';
import { MisCursosComponent } from './features/alumno/mis-cursos/mis-cursos';
import { MisNotasComponent } from './features/alumno/mis-notas/mis-notas';

export const routes: Routes = [

  {
    path: 'login',
    component: LoginComponent
  },

  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [authGuard]
  },
  
  {
  path: 'admin/usuarios',
  component: UsuariosComponent,
  canActivate: [authGuard]
   },

   {
  path: 'admin/docentes',
  component: DocentesComponent,
  canActivate: [authGuard]
   },

   {
  path: 'admin/alumnos',
  component: AlumnosComponent,
  canActivate: [authGuard]
   },

   {
  path: 'admin/cursos',
  component: CursosComponent,
  canActivate: [authGuard]
   },

   {
  path: 'admin/secciones',
  component: SeccionesComponent,
  canActivate: [authGuard]
   },

   {
  path: 'admin/asignaciones',
  component: AsignacionesComponent,
  canActivate: [authGuard]
   },

   {
  path: 'admin/matriculas',
  component: MatriculasComponent,
  canActivate: [authGuard]
   },

  {
    path: 'docente',
    component: DocenteComponent,
    canActivate: [authGuard]
  },

  {
  path: 'docente/curso/:idCurso',
  component: CursoDetalleComponent,
  canActivate: [authGuard]
  },

  {
  path: 'docente/curso/:idCurso/alumno/:idAlumno/nota',
  component: RegistrarNotaComponent,
  canActivate: [authGuard]
  },

  {
  path: 'docente/curso/:idCurso/notas',
  component: NotasCursoComponent,
  canActivate: [authGuard]
  },

  {
    path: 'alumno',
    component: AlumnoComponent,
    canActivate: [authGuard]
  },

  {
  path: 'alumno/cursos',
  component: MisCursosComponent,
  canActivate: [authGuard]
  },

  {
  path: 'alumno/notas',
  component: MisNotasComponent,
  canActivate: [authGuard]
  },

  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },

  {
    path: '**',
    redirectTo: 'login'
  }

];