import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AlumnoService } from '../../../core/services/alumno.service';
import { Curso } from '../../../core/models/curso.model';

@Component({
  selector: 'app-mis-cursos',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './mis-cursos.html',
  styleUrl: './mis-cursos.css'
})
export class MisCursosComponent implements OnInit {

  private readonly alumnoService = inject(AlumnoService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  cursos: Curso[] = [];
  cursosFiltrados: Curso[] = [];

  busqueda = '';

  cargando = true;
  error = '';

  ngOnInit(): void {
    this.cargarCursos();
  }

  volverPortal(): void {
    this.router.navigate(['/alumno']);
  }

  cargarCursos(): void {

    this.cargando = true;
    this.error = '';

    this.alumnoService
      .misCursos()
      .subscribe({

        next: (cursos) => {

          this.cursos = cursos;
          this.cursosFiltrados = cursos;

          this.cargando = false;

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error cargando cursos:',
            error
          );

          this.error =
            'No se pudieron cargar tus cursos.';

          this.cargando = false;

          this.cdr.detectChanges();
        }

      });
  }

  buscar(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    if (!texto) {
      this.cursosFiltrados = this.cursos;
      return;
    }

    this.cursosFiltrados =
      this.cursos.filter(curso =>

        curso.nombre
          .toLowerCase()
          .includes(texto) ||

        curso.descripcion
          ?.toLowerCase()
          .includes(texto) ||

        curso.seccion
          ?.toLowerCase()
          .includes(texto)

      );
  }
}