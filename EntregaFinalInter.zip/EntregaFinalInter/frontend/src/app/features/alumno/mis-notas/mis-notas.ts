import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AlumnoService } from '../../../core/services/alumno.service';
import { Nota } from '../../../core/models/nota.model';

@Component({
  selector: 'app-mis-notas',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './mis-notas.html',
  styleUrl: './mis-notas.css'
})
export class MisNotasComponent implements OnInit {

  private readonly alumnoService = inject(AlumnoService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  notas: Nota[] = [];
  notasFiltradas: Nota[] = [];

  busqueda = '';

  cargando = true;
  error = '';

  ngOnInit(): void {
    this.cargarNotas();
  }

  volverPortal(): void {
    this.router.navigate(['/alumno']);
  }

  cargarNotas(): void {

    this.cargando = true;
    this.error = '';

    this.alumnoService
      .misNotas()
      .subscribe({

        next: (notas) => {

          this.notas = notas;
          this.notasFiltradas = notas;

          this.cargando = false;

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error cargando notas:',
            error
          );

          this.error =
            'No se pudieron cargar tus notas.';

          this.cargando = false;

          this.cdr.detectChanges();
        }

      });
  }

  buscar(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    if (!texto) {
      this.notasFiltradas = this.notas;
      return;
    }

    this.notasFiltradas =
      this.notas.filter(nota =>

        nota.curso
          .toLowerCase()
          .includes(texto) ||

        nota.nombreEvaluacion
          .toLowerCase()
          .includes(texto) ||

        nota.calificacion
          .toString()
          .includes(texto)

      );
  }

  getPromedioSimple(): number {

    if (this.notas.length === 0) {
      return 0;
    }

    const total = this.notas.reduce(
      (suma, nota) =>
        suma + Number(nota.calificacion),
      0
    );

    return total / this.notas.length;
  }

  getAprobadas(): number {

    return this.notas.filter(
      nota => nota.calificacion >= 11
    ).length;
  }

  getDesaprobadas(): number {

    return this.notas.filter(
      nota => nota.calificacion < 11
    ).length;
  }
}