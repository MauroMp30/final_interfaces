import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { AlumnoService } from '../../core/services/alumno.service';

import { Curso } from '../../core/models/curso.model';
import { Nota } from '../../core/models/nota.model';

@Component({
  selector: 'app-alumno',
  standalone: true,
  imports: [
    CommonModule
  ],
  templateUrl: './alumno.html',
  styleUrl: './alumno.css'
})
export class AlumnoComponent implements OnInit {

  private readonly alumnoService = inject(AlumnoService);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  username = '';

  cursos: Curso[] = [];
  notas: Nota[] = [];

  cargando = true;
  error = '';

  ngOnInit(): void {

    this.username =
      this.authService.getUsername() ?? 'Estudiante';

    this.cargarDatos();
  }

  cargarDatos(): void {

    this.cargando = true;
    this.error = '';

    forkJoin({
      cursos: this.alumnoService.misCursos(),
      notas: this.alumnoService.misNotas()
    }).subscribe({

      next: (datos) => {

        this.cursos = datos.cursos;
        this.notas = datos.notas;

        this.cargando = false;

        this.cdr.detectChanges();
      },

      error: (error) => {

        console.error(
          'Error cargando datos del estudiante:',
          error
        );

        this.error =
          'No se pudo cargar tu información académica.';

        this.cargando = false;

        this.cdr.detectChanges();
      }

    });
  }

  verCursos(): void {
    this.router.navigate(['/alumno/cursos']);
  }

  verNotas(): void {
    this.router.navigate(['/alumno/notas']);
  }

  cerrarSesion(): void {

    this.authService.logout();

    this.router.navigate(['/login']);
  }
}