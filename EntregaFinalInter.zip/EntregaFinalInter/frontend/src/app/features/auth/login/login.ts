import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import {
  AuthService,
  LoginRequest
} from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './login.html',
  styleUrl: './login.css'
})

export class LoginComponent {

  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);

  username = '';
  password = '';

  cargando = false;
  error = '';

  iniciarSesion(): void {

    this.error = '';

    if (!this.username.trim() || !this.password.trim()) {
      this.error = 'Ingresa tu usuario y contraseña.';
      return;
    }

    this.cargando = true;

    const request: LoginRequest = {
      username: this.username.trim(),
      password: this.password
    };

    this.authService.login(request).subscribe({
      next: (response) => {

        this.cargando = false;

        switch (response.rol) {

          case 'ADMIN':
            this.router.navigate(['/admin']);
            break;

          case 'DOCENTE':
            this.router.navigate(['/docente']);
            break;

          case 'ESTUDIANTE':
            this.router.navigate(['/alumno']);
            break;

          default:
            this.error = 'El usuario no tiene un rol válido.';
        }
      },

      error: (error) => {

        this.cargando = false;

        if (error.status === 401) {
          this.error = 'Usuario o contraseña incorrectos.';
        } else {
          this.error = 'No se pudo conectar con el servidor.';
        }
      }
    });
  }
}