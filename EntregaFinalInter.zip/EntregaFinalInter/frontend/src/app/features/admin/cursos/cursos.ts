import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { CursoService } from '../../../core/services/curso.service';
import { AdminService } from '../../../core/services/admin.service';

import {
  Curso,
  CursoRequest
} from '../../../core/models/curso.model';

import { Seccion } from '../../../core/models/seccion.model';

@Component({
  selector: 'app-cursos',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './cursos.html',
  styleUrl: './cursos.css'
})
export class CursosComponent implements OnInit {

  private readonly cursoService = inject(CursoService);
  private readonly adminService = inject(AdminService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  cursos: Curso[] = [];
  cursosFiltrados: Curso[] = [];
  secciones: Seccion[] = [];

  busqueda = '';

  cargando = true;
  guardando = false;

  error = '';
  mensajeExito = '';
  mensajeError = '';

  mostrarFormulario = false;

  nuevoCurso: CursoRequest = {
    nombre: '',
    descripcion: '',
    creditos: 1,
    idSeccion: null
  };

  ngOnInit(): void {
    this.cargarDatos();
  }

  volverDashboard(): void {
    this.router.navigate(['/admin']);
  }

  cargarDatos(): void {
    this.cargando = true;
    this.error = '';

    this.cursoService.listarCursos().subscribe({
      next: (cursos) => {

        this.cursos = cursos;
        this.cursosFiltrados = cursos;

        this.adminService.listarSecciones().subscribe({
          next: (secciones) => {
            this.secciones = secciones;

            this.cargando = false;
            this.cdr.detectChanges();
          },

          error: (error) => {
            console.error(
              'Error cargando secciones:',
              error
            );

            this.error =
              'No se pudieron cargar las secciones.';

            this.cargando = false;
            this.cdr.detectChanges();
          }
        });
      },

      error: (error) => {
        console.error(
          'Error cargando cursos:',
          error
        );

        this.error =
          'No se pudieron cargar los cursos.';

        this.cargando = false;
        this.cdr.detectChanges();
      }
    });
  }

  buscar(): void {
    const texto = this.busqueda
      .trim()
      .toLowerCase();

    if (!texto) {
      this.cursosFiltrados = this.cursos;
      return;
    }

    this.cursosFiltrados = this.cursos.filter(curso =>
      curso.nombre.toLowerCase().includes(texto) ||
      curso.descripcion?.toLowerCase().includes(texto) ||
      curso.seccion?.toLowerCase().includes(texto)
    );
  }

  abrirFormulario(): void {
    this.mostrarFormulario = true;

    this.mensajeExito = '';
    this.mensajeError = '';
  }

  cerrarFormulario(): void {
    this.mostrarFormulario = false;
    this.limpiarFormulario();
  }

  limpiarFormulario(): void {
    this.nuevoCurso = {
      nombre: '',
      descripcion: '',
      creditos: 1,
      idSeccion: null
    };
  }

  guardarCurso(): void {

    this.mensajeExito = '';
    this.mensajeError = '';

    if (!this.nuevoCurso.nombre.trim()) {
      this.mensajeError =
        'Ingresa el nombre del curso.';
      return;
    }

    if (
      this.nuevoCurso.creditos < 1
    ) {
      this.mensajeError =
        'Los créditos deben ser mayores a 0.';
      return;
    }

    this.guardando = true;

    this.cursoService
      .crearCurso(this.nuevoCurso)
      .subscribe({

        next: (cursoCreado) => {

          this.cursos = [
            ...this.cursos,
            cursoCreado
          ];

          this.cursosFiltrados = this.cursos;

          this.mensajeExito =
            `Curso ${cursoCreado.nombre} creado correctamente.`;

          this.guardando = false;
          this.mostrarFormulario = false;

          this.limpiarFormulario();

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error creando curso:',
            error
          );

          this.guardando = false;

          this.mensajeError =
            error.error?.mensaje ??
            'No se pudo crear el curso.';

          this.cdr.detectChanges();
        }
      });
  }
}