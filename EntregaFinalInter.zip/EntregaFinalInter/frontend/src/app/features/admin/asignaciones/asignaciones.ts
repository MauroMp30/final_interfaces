import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';

import { AdminService } from '../../../core/services/admin.service';
import { CursoService } from '../../../core/services/curso.service';

import {
  Asignacion,
  AsignacionRequest
} from '../../../core/models/asignacion.model';

import { Docente } from '../../../core/models/docente.model';
import { Curso } from '../../../core/models/curso.model';

@Component({
  selector: 'app-asignaciones',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './asignaciones.html',
  styleUrl: './asignaciones.css'
})
export class AsignacionesComponent implements OnInit {

  private readonly adminService = inject(AdminService);
  private readonly cursoService = inject(CursoService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  asignaciones: Asignacion[] = [];
  asignacionesFiltradas: Asignacion[] = [];

  docentes: Docente[] = [];
  cursos: Curso[] = [];

  busqueda = '';

  cargando = true;
  guardando = false;

  error = '';
  mensajeExito = '';
  mensajeError = '';

  mostrarFormulario = false;

  nuevaAsignacion: AsignacionRequest = {
    idDocente: 0,
    idCurso: 0
  };

  ngOnInit(): void {
    this.cargarDatos();
  }

  volverDashboard(): void {
    this.router.navigate(['/admin']);
  }

  cargarDatos(): void {
    this.cargando = true;
    this.error = '';

    forkJoin({
      asignaciones: this.adminService.listarAsignaciones(),
      docentes: this.adminService.listarDocentes(),
      cursos: this.cursoService.listarCursos()
    }).subscribe({

      next: (datos) => {
        this.asignaciones = datos.asignaciones;
        this.asignacionesFiltradas = datos.asignaciones;

        this.docentes = datos.docentes;
        this.cursos = datos.cursos;

        this.cargando = false;
        this.cdr.detectChanges();
      },

      error: (error) => {
        console.error(
          'Error cargando asignaciones:',
          error
        );

        this.error =
          'No se pudo cargar la información de asignaciones.';

        this.cargando = false;
        this.cdr.detectChanges();
      }
    });
  }

  buscar(): void {
    const texto = this.busqueda
      .trim()
      .toLowerCase();

    if (!texto) {
      this.asignacionesFiltradas = this.asignaciones;
      return;
    }

    this.asignacionesFiltradas =
      this.asignaciones.filter(asignacion =>
        asignacion.docente
          .toLowerCase()
          .includes(texto) ||

        asignacion.curso
          .toLowerCase()
          .includes(texto) ||

        asignacion.fechaAsignacion
          ?.toLowerCase()
          .includes(texto)
      );
  }

  abrirFormulario(): void {
    this.mostrarFormulario = true;

    this.mensajeExito = '';
    this.mensajeError = '';

    this.nuevaAsignacion = {
      idDocente: 0,
      idCurso: 0
    };
  }

  cerrarFormulario(): void {
    this.mostrarFormulario = false;

    this.nuevaAsignacion = {
      idDocente: 0,
      idCurso: 0
    };
  }

  guardarAsignacion(): void {

    this.mensajeExito = '';
    this.mensajeError = '';

    if (
      !this.nuevaAsignacion.idDocente ||
      this.nuevaAsignacion.idDocente === 0
    ) {
      this.mensajeError =
        'Selecciona un docente.';
      return;
    }

    if (
      !this.nuevaAsignacion.idCurso ||
      this.nuevaAsignacion.idCurso === 0
    ) {
      this.mensajeError =
        'Selecciona un curso.';
      return;
    }

    this.guardando = true;

    this.adminService
      .crearAsignacion(this.nuevaAsignacion)
      .subscribe({

        next: (asignacionCreada) => {

          this.asignaciones = [
            ...this.asignaciones,
            asignacionCreada
          ];

          this.asignacionesFiltradas =
            this.asignaciones;

          this.mensajeExito =
            `Asignación creada correctamente: ${asignacionCreada.docente} → ${asignacionCreada.curso}.`;

          this.guardando = false;
          this.mostrarFormulario = false;

          this.nuevaAsignacion = {
            idDocente: 0,
            idCurso: 0
          };

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error creando asignación:',
            error
          );

          this.guardando = false;

          this.mensajeError =
            error.error?.mensaje ??
            'No se pudo crear la asignación.';

          this.cdr.detectChanges();
        }
      });
  }
}