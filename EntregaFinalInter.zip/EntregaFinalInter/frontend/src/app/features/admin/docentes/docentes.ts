import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AdminService } from '../../../core/services/admin.service';
import { Docente } from '../../../core/models/docente.model';

@Component({
  selector: 'app-docentes',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './docentes.html',
  styleUrl: './docentes.css'
})
export class DocentesComponent implements OnInit {

  private readonly adminService = inject(AdminService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  docentes: Docente[] = [];
  docentesFiltrados: Docente[] = [];

  busqueda = '';

  cargando = true;
  error = '';

  ngOnInit(): void {
    this.cargarDocentes();
  }

  volverDashboard(): void {
    this.router.navigate(['/admin']);
  }

  cargarDocentes(): void {
    this.cargando = true;
    this.error = '';

    this.adminService.listarDocentes().subscribe({
      next: (docentes) => {
        this.docentes = docentes;
        this.docentesFiltrados = docentes;

        this.cargando = false;
        this.cdr.detectChanges();
      },

      error: (error) => {
        console.error('Error cargando docentes:', error);

        this.error = 'No se pudieron cargar los docentes.';
        this.cargando = false;

        this.cdr.detectChanges();
      }
    });
  }

  buscar(): void {
    const texto = this.busqueda.trim().toLowerCase();

    if (!texto) {
      this.docentesFiltrados = this.docentes;
      return;
    }

    this.docentesFiltrados = this.docentes.filter(docente =>
      docente.nombreCompleto.toLowerCase().includes(texto) ||
      docente.username.toLowerCase().includes(texto) ||
      docente.especialidad?.toLowerCase().includes(texto) ||
      docente.gradoAcademico?.toLowerCase().includes(texto) ||
      docente.telefono?.toLowerCase().includes(texto)
    );
  }
}