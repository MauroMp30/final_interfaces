import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AdminService } from '../../../core/services/admin.service';
import { Alumno } from '../../../core/models/alumno.model';

@Component({
  selector: 'app-alumnos',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './alumnos.html',
  styleUrl: './alumnos.css'
})
export class AlumnosComponent implements OnInit {

  private readonly adminService = inject(AdminService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  alumnos: Alumno[] = [];
  alumnosFiltrados: Alumno[] = [];

  busqueda = '';

  cargando = true;
  error = '';

  ngOnInit(): void {
    this.cargarAlumnos();
  }

  volverDashboard(): void {
    this.router.navigate(['/admin']);
  }

  cargarAlumnos(): void {
    this.cargando = true;
    this.error = '';

    this.adminService.listarAlumnos().subscribe({
      next: (alumnos) => {
        this.alumnos = alumnos;
        this.alumnosFiltrados = alumnos;

        this.cargando = false;
        this.cdr.detectChanges();
      },

      error: (error) => {
        console.error('Error cargando alumnos:', error);

        this.error = 'No se pudieron cargar los alumnos.';
        this.cargando = false;

        this.cdr.detectChanges();
      }
    });
  }

  buscar(): void {
    const texto = this.busqueda.trim().toLowerCase();

    if (!texto) {
      this.alumnosFiltrados = this.alumnos;
      return;
    }

    this.alumnosFiltrados = this.alumnos.filter(alumno =>
      alumno.nombreCompleto.toLowerCase().includes(texto) ||
      alumno.username.toLowerCase().includes(texto) ||
      alumno.dniApoderado?.toLowerCase().includes(texto) ||
      alumno.telefono?.toLowerCase().includes(texto) ||
      alumno.fechaNacimiento?.toLowerCase().includes(texto)
    );
  }
}