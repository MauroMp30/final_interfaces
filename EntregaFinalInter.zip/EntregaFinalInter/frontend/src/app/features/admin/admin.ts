import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { AdminService } from '../../core/services/admin.service';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin.html',
  styleUrl: './admin.css'
})
export class AdminComponent implements OnInit {

  private readonly adminService = inject(AdminService);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  username = '';

  cargando = true;
  error = '';

  totalUsuarios = 0;
  totalDocentes = 0;
  totalAlumnos = 0;
  totalSecciones = 0;
  totalAsignaciones = 0;
  totalMatriculas = 0;

  ngOnInit(): void {
    this.username = this.authService.getUsername() ?? 'Administrador';
    this.cargarDashboard();
  }

  cargarDashboard(): void {
    this.cargando = true;
    this.error = '';

    forkJoin({
      usuarios: this.adminService.listarUsuarios(),
      docentes: this.adminService.listarDocentes(),
      alumnos: this.adminService.listarAlumnos(),
      secciones: this.adminService.listarSecciones(),
      asignaciones: this.adminService.listarAsignaciones(),
      matriculas: this.adminService.listarMatriculas()
    }).subscribe({
      next: (datos) => {
        this.totalUsuarios = datos.usuarios.length;
        this.totalDocentes = datos.docentes.length;
        this.totalAlumnos = datos.alumnos.length;
        this.totalSecciones = datos.secciones.length;
        this.totalAsignaciones = datos.asignaciones.length;
        this.totalMatriculas = datos.matriculas.length;

        this.cargando = false;

        this.cdr.detectChanges();
      },

      error: (error) => {
        console.error('Error al cargar dashboard:', error);

        this.error =
          'No se pudo cargar la información del sistema. Intenta nuevamente.';

        this.cargando = false;

        this.cdr.detectChanges();
      }
    });
  }
  
  irAUsuarios(): void {
  this.router.navigate(['/admin/usuarios']);
}

irADocentes(): void {
  this.router.navigate(['/admin/docentes']);
}

irAAlumnos(): void {
  this.router.navigate(['/admin/alumnos']);
}

irACursos(): void {
  this.router.navigate(['/admin/cursos']);
}

irASecciones(): void {
  this.router.navigate(['/admin/secciones']);
}

irAAsignaciones(): void {
  this.router.navigate(['/admin/asignaciones']);
}

irAMatriculas(): void {
  this.router.navigate(['/admin/matriculas']);
}

  cerrarSesion(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}