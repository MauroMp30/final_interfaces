import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { UsuarioRequest } from '../../../core/services/admin.service';

import { AdminService } from '../../../core/services/admin.service';
import { Usuario } from '../../../core/models/usuario.model';

@Component({
  selector: 'app-usuarios',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './usuarios.html',
  styleUrl: './usuarios.css'
})
export class UsuariosComponent implements OnInit {


  private readonly adminService = inject(AdminService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly router = inject(Router);

  mostrarFormulario = false;
guardando = false;

mensajeExito = '';
mensajeError = '';

nuevoUsuario: UsuarioRequest = {
  username: '',
  password: '',
  dni: '',
  nombre: '',
  apellido: '',
  email: '',
  rol: 'ESTUDIANTE',

  telefono: '',
  dniApoderado: '',
  fechaNacimiento: '',
  especialidad: '',
  gradoAcademico: ''
};

  usuarios: Usuario[] = [];
  usuariosFiltrados: Usuario[] = [];

  busqueda = '';

  cargando = true;
  error = '';

  ngOnInit(): void {
    this.cargarUsuarios();
  }

  volverDashboard(): void {
    this.router.navigate(['/admin']);
  }

  cargarUsuarios(): void {
    this.cargando = true;
    this.error = '';

    this.adminService.listarUsuarios().subscribe({
      next: (usuarios) => {
        this.usuarios = usuarios;
        this.usuariosFiltrados = usuarios;

        this.cargando = false;
        this.cdr.detectChanges();
      },

      error: (error) => {
        console.error('Error cargando usuarios:', error);

        this.error = 'No se pudieron cargar los usuarios.';
        this.cargando = false;

        this.cdr.detectChanges();
      }
    });
  }

  buscar(): void {
    const texto = this.busqueda
      .trim()
      .toLowerCase();

    if (!texto) {
      this.usuariosFiltrados = this.usuarios;
      return;
    }

    this.usuariosFiltrados = this.usuarios.filter(usuario =>
      usuario.nombre.toLowerCase().includes(texto) ||
      usuario.apellido.toLowerCase().includes(texto) ||
      usuario.username.toLowerCase().includes(texto) ||
      usuario.dni?.toLowerCase().includes(texto) ||
      usuario.email.toLowerCase().includes(texto) ||
      usuario.rol.toLowerCase().includes(texto)
    );
  }

abrirFormulario(): void {
  this.mostrarFormulario = true;
  this.mensajeExito = '';
  this.mensajeError = '';
}

cerrarFormulario(): void {
  this.mostrarFormulario = false;
  this.limpiarFormulario();
}

limpiarFormulario(): void {
  this.nuevoUsuario = {
    username: '',
    password: '',
    dni: '',
    nombre: '',
    apellido: '',
    email: '',
    rol: 'ESTUDIANTE',

    telefono: '',
    dniApoderado: '',
    fechaNacimiento: '',
    especialidad: '',
    gradoAcademico: ''
  };
}

guardarUsuario(): void {

  this.mensajeExito = '';
  this.mensajeError = '';

  if (
    !this.nuevoUsuario.username.trim() ||
    !this.nuevoUsuario.password.trim() ||
    !this.nuevoUsuario.dni.trim() ||
    !this.nuevoUsuario.nombre.trim() ||
    !this.nuevoUsuario.apellido.trim() ||
    !this.nuevoUsuario.email.trim()
  ) {
    this.mensajeError = 'Completa todos los campos obligatorios.';
    return;
  }

  if (this.nuevoUsuario.dni.length !== 8) {
    this.mensajeError = 'El DNI debe tener 8 caracteres.';
    return;
  }

  if (this.nuevoUsuario.password.length < 6) {
    this.mensajeError =
      'La contraseña debe tener al menos 6 caracteres.';
    return;
  }

  if (
    this.nuevoUsuario.rol === 'ESTUDIANTE' &&
    !this.nuevoUsuario.fechaNacimiento
  ) {
    this.mensajeError =
      'Ingresa la fecha de nacimiento del estudiante.';
    return;
  }

  if (
    this.nuevoUsuario.rol === 'DOCENTE' &&
    !this.nuevoUsuario.especialidad?.trim()
  ) {
    this.mensajeError =
      'Ingresa la especialidad del docente.';
    return;
  }

  this.guardando = true;

  this.adminService.crearUsuario(
    this.nuevoUsuario
  ).subscribe({

    next: (usuarioCreado) => {

      this.usuarios = [
        ...this.usuarios,
        usuarioCreado
      ];

      this.usuariosFiltrados = this.usuarios;

      this.mensajeExito =
        `Usuario ${usuarioCreado.username} creado correctamente.`;

      this.guardando = false;
      this.mostrarFormulario = false;

      this.limpiarFormulario();

      this.cdr.detectChanges();
    },

    error: (error) => {

      console.error(
        'Error creando usuario:',
        error
      );

      this.guardando = false;

      this.mensajeError =
        error.error?.mensaje ??
        'No se pudo crear el usuario.';

      this.cdr.detectChanges();
    }
  });
}

}