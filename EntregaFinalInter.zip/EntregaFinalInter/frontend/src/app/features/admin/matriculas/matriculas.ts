import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';

import { AdminService } from '../../../core/services/admin.service';

import {
  Matricula,
  MatriculaRequest
} from '../../../core/models/matricula.model';

import { Alumno } from '../../../core/models/alumno.model';
import { Seccion } from '../../../core/models/seccion.model';

@Component({
  selector: 'app-matriculas',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './matriculas.html',
  styleUrl: './matriculas.css'
})
export class MatriculasComponent implements OnInit {

  private readonly adminService = inject(AdminService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  matriculas: Matricula[] = [];
  matriculasFiltradas: Matricula[] = [];

  alumnos: Alumno[] = [];
  secciones: Seccion[] = [];

  busqueda = '';

  cargando = true;
  guardando = false;

  error = '';
  mensajeExito = '';
  mensajeError = '';

  mostrarFormulario = false;

  nuevaMatricula: MatriculaRequest = {
    idAlumno: 0,
    idSeccion: 0
  };

  ngOnInit(): void {
    this.cargarDatos();
  }

  volverDashboard(): void {
    this.router.navigate(['/admin']);
  }

  cargarDatos(): void {
    this.cargando = true;
    this.error = '';

    forkJoin({
      matriculas: this.adminService.listarMatriculas(),
      alumnos: this.adminService.listarAlumnos(),
      secciones: this.adminService.listarSecciones()
    }).subscribe({

      next: (datos) => {

        this.matriculas = datos.matriculas;
        this.matriculasFiltradas = datos.matriculas;

        this.alumnos = datos.alumnos;
        this.secciones = datos.secciones;

        this.cargando = false;

        this.cdr.detectChanges();
      },

      error: (error) => {

        console.error(
          'Error cargando matrículas:',
          error
        );

        this.error =
          'No se pudo cargar la información de matrículas.';

        this.cargando = false;

        this.cdr.detectChanges();
      }

    });
  }

  buscar(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    if (!texto) {
      this.matriculasFiltradas = this.matriculas;
      return;
    }

    this.matriculasFiltradas =
      this.matriculas.filter(matricula =>
        matricula.alumno
          .toLowerCase()
          .includes(texto) ||

        matricula.seccion
          .toLowerCase()
          .includes(texto) ||

        matricula.fechaMatricula
          ?.toLowerCase()
          .includes(texto)
      );
  }

  abrirFormulario(): void {

    this.mostrarFormulario = true;

    this.mensajeExito = '';
    this.mensajeError = '';

    this.nuevaMatricula = {
      idAlumno: 0,
      idSeccion: 0
    };
  }

  cerrarFormulario(): void {

    this.mostrarFormulario = false;

    this.nuevaMatricula = {
      idAlumno: 0,
      idSeccion: 0
    };
  }

  guardarMatricula(): void {

    this.mensajeExito = '';
    this.mensajeError = '';

    if (
      !this.nuevaMatricula.idAlumno ||
      this.nuevaMatricula.idAlumno === 0
    ) {

      this.mensajeError =
        'Selecciona un alumno.';

      return;
    }

    if (
      !this.nuevaMatricula.idSeccion ||
      this.nuevaMatricula.idSeccion === 0
    ) {

      this.mensajeError =
        'Selecciona una sección.';

      return;
    }

    this.guardando = true;

    this.adminService
      .crearMatricula(this.nuevaMatricula)
      .subscribe({

        next: (matriculaCreada) => {

          this.matriculas = [
            ...this.matriculas,
            matriculaCreada
          ];

          this.matriculasFiltradas =
            this.matriculas;

          this.mensajeExito =
            `Matrícula creada correctamente: ${matriculaCreada.alumno} → ${matriculaCreada.seccion}.`;

          this.guardando = false;
          this.mostrarFormulario = false;

          this.nuevaMatricula = {
            idAlumno: 0,
            idSeccion: 0
          };

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error creando matrícula:',
            error
          );

          this.guardando = false;

          this.mensajeError =
            error.error?.mensaje ??
            'No se pudo crear la matrícula.';

          this.cdr.detectChanges();
        }

      });
  }
}