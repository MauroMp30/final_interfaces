import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AdminService } from '../../../core/services/admin.service';
import { Seccion } from '../../../core/models/seccion.model';

@Component({
  selector: 'app-secciones',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './secciones.html',
  styleUrl: './secciones.css'
})
export class SeccionesComponent implements OnInit {

  private readonly adminService = inject(AdminService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  secciones: Seccion[] = [];
  seccionesFiltradas: Seccion[] = [];

  busqueda = '';

  cargando = true;
  error = '';

  ngOnInit(): void {
    this.cargarSecciones();
  }

  volverDashboard(): void {
    this.router.navigate(['/admin']);
  }

  cargarSecciones(): void {
    this.cargando = true;
    this.error = '';

    this.adminService.listarSecciones().subscribe({

      next: (secciones) => {

        this.secciones = secciones;
        this.seccionesFiltradas = secciones;

        this.cargando = false;
        this.cdr.detectChanges();
      },

      error: (error) => {

        console.error(
          'Error cargando secciones:',
          error
        );

        this.error =
          'No se pudieron cargar las secciones.';

        this.cargando = false;
        this.cdr.detectChanges();
      }

    });
  }

  buscar(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    if (!texto) {
      this.seccionesFiltradas = this.secciones;
      return;
    }

    this.seccionesFiltradas =
      this.secciones.filter(seccion =>
        seccion.nombreSeccion
          .toLowerCase()
          .includes(texto) ||

        seccion.periodoAcademico
          .toLowerCase()
          .includes(texto) ||

        seccion.capacidadMaxima
          .toString()
          .includes(texto)
      );
  }
}