import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { DocenteService } from '../../core/services/docente.service';
import { Curso } from '../../core/models/curso.model';

@Component({
  selector: 'app-docente',
  standalone: true,
  imports: [
    CommonModule
  ],
  templateUrl: './docente.html',
  styleUrl: './docente.css'
})
export class DocenteComponent implements OnInit {

  private readonly docenteService = inject(DocenteService);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  username = '';

  cursos: Curso[] = [];

  cargando = true;
  error = '';

  ngOnInit(): void {

    this.username =
      this.authService.getUsername() ?? 'Docente';

    this.cargarCursos();
  }

  cargarCursos(): void {

    this.cargando = true;
    this.error = '';

    this.docenteService
      .misCursos()
      .subscribe({

        next: (cursos) => {

          this.cursos = cursos;

          this.cargando = false;

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error cargando cursos del docente:',
            error
          );

          this.error =
            'No se pudieron cargar tus cursos.';

          this.cargando = false;

          this.cdr.detectChanges();
        }

      });
  }

  verCurso(curso: Curso): void {

    this.router.navigate([
      '/docente/curso',
      curso.idCurso
    ]);
  }

  cerrarSesion(): void {

    this.authService.logout();

    this.router.navigate(['/login']);
  }
}