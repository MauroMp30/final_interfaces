import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { DocenteService } from '../../../core/services/docente.service';

import {
  NotaRequest
} from '../../../core/models/nota.model';

import {
  Alumno
} from '../../../core/models/alumno.model';

@Component({
  selector: 'app-registrar-nota',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './registrar-nota.html',
  styleUrl: './registrar-nota.css'
})
export class RegistrarNotaComponent implements OnInit {

  private readonly docenteService = inject(DocenteService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  idCurso = 0;
  idAlumno = 0;

  alumno: Alumno | null = null;

  cargando = true;
  guardando = false;

  error = '';
  mensajeExito = '';
  mensajeError = '';

  nota: NotaRequest = {
    idCurso: 0,
    idAlumno: 0,
    nombreEvaluacion: '',
    calificacion: 0,
    ponderacion: 0
  };

  ngOnInit(): void {

    this.idCurso = Number(
      this.route.snapshot.paramMap.get('idCurso')
    );

    this.idAlumno = Number(
      this.route.snapshot.paramMap.get('idAlumno')
    );

    if (!this.idCurso || !this.idAlumno) {
      this.router.navigate(['/docente']);
      return;
    }

    this.nota.idCurso = this.idCurso;
    this.nota.idAlumno = this.idAlumno;

    this.cargarAlumno();
  }

  cargarAlumno(): void {

    this.cargando = true;
    this.error = '';

    this.docenteService
      .alumnosPorCurso(this.idCurso)
      .subscribe({

        next: (alumnos) => {

          this.alumno =
            alumnos.find(
              alumno =>
                alumno.idAlumno === this.idAlumno
            ) ?? null;

          if (!this.alumno) {

            this.error =
              'El alumno no pertenece a este curso.';

          }

          this.cargando = false;

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error cargando alumno:',
            error
          );

          this.error =
            error.error?.mensaje ??
            'No se pudo cargar la información del alumno.';

          this.cargando = false;

          this.cdr.detectChanges();
        }

      });
  }

  volverCurso(): void {

    this.router.navigate([
      '/docente/curso',
      this.idCurso
    ]);
  }

  guardarNota(): void {

    this.mensajeExito = '';
    this.mensajeError = '';

    if (!this.nota.nombreEvaluacion.trim()) {

      this.mensajeError =
        'Ingresa el nombre de la evaluación.';

      return;
    }

    if (
      this.nota.calificacion < 0 ||
      this.nota.calificacion > 20
    ) {

      this.mensajeError =
        'La calificación debe estar entre 0 y 20.';

      return;
    }

    if (
      this.nota.ponderacion < 0 ||
      this.nota.ponderacion > 100
    ) {

      this.mensajeError =
        'La ponderación debe estar entre 0 y 100.';

      return;
    }

    this.guardando = true;

    this.docenteService
      .registrarNota(this.nota)
      .subscribe({

        next: () => {

          this.mensajeExito =
            'Nota registrada correctamente.';

          this.guardando = false;

          this.nota.nombreEvaluacion = '';
          this.nota.calificacion = 0;
          this.nota.ponderacion = 0;

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error registrando nota:',
            error
          );

          this.guardando = false;

          this.mensajeError =
            error.error?.mensaje ??
            'No se pudo registrar la nota.';

          this.cdr.detectChanges();
        }

      });
  }
}