import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { DocenteService } from '../../../core/services/docente.service';
import { Nota } from '../../../core/models/nota.model';

@Component({
  selector: 'app-notas-curso',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './notas-curso.html',
  styleUrl: './notas-curso.css'
})
export class NotasCursoComponent implements OnInit {

  private readonly docenteService = inject(DocenteService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  idCurso = 0;

  notas: Nota[] = [];
  notasFiltradas: Nota[] = [];

  busqueda = '';

  cargando = true;
  error = '';

  ngOnInit(): void {

    this.idCurso = Number(
      this.route.snapshot.paramMap.get('idCurso')
    );

    if (!this.idCurso) {
      this.router.navigate(['/docente']);
      return;
    }

    this.cargarNotas();
  }

  volverCurso(): void {
    this.router.navigate([
      '/docente/curso',
      this.idCurso
    ]);
  }

  cargarNotas(): void {

    this.cargando = true;
    this.error = '';

    this.docenteService
      .notasPorCurso(this.idCurso)
      .subscribe({

        next: (notas) => {

          this.notas = notas;
          this.notasFiltradas = notas;

          this.cargando = false;

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error cargando notas:',
            error
          );

          this.error =
            error.error?.mensaje ??
            'No se pudieron cargar las notas del curso.';

          this.cargando = false;

          this.cdr.detectChanges();
        }

      });
  }

  buscar(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    if (!texto) {
      this.notasFiltradas = this.notas;
      return;
    }

    this.notasFiltradas =
      this.notas.filter(nota =>
        nota.alumno
          .toLowerCase()
          .includes(texto) ||

        nota.nombreEvaluacion
          .toLowerCase()
          .includes(texto) ||

        nota.calificacion
          .toString()
          .includes(texto)
      );
  }

  getPromedio(): number {

    if (this.notas.length === 0) {
      return 0;
    }

    const total = this.notas.reduce(
      (suma, nota) =>
        suma + Number(nota.calificacion),
      0
    );

    return total / this.notas.length;
  }
}