import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { DocenteService } from '../../../core/services/docente.service';
import { Alumno } from '../../../core/models/alumno.model';

@Component({
  selector: 'app-curso-detalle',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './curso-detalle.html',
  styleUrl: './curso-detalle.css'
})
export class CursoDetalleComponent implements OnInit {

  private readonly docenteService = inject(DocenteService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  idCurso = 0;

  alumnos: Alumno[] = [];
  alumnosFiltrados: Alumno[] = [];

  busqueda = '';

  cargando = true;
  error = '';

  ngOnInit(): void {

    this.idCurso = Number(
      this.route.snapshot.paramMap.get('idCurso')
    );

    if (!this.idCurso) {

      this.router.navigate(['/docente']);
      return;
    }

    this.cargarAlumnos();
  }

  volverDashboard(): void {
    this.router.navigate(['/docente']);
  }

  cargarAlumnos(): void {

    this.cargando = true;
    this.error = '';

    this.docenteService
      .alumnosPorCurso(this.idCurso)
      .subscribe({

        next: (alumnos) => {

          this.alumnos = alumnos;
          this.alumnosFiltrados = alumnos;

          this.cargando = false;

          this.cdr.detectChanges();
        },

        error: (error) => {

          console.error(
            'Error cargando alumnos del curso:',
            error
          );

          this.error =
            error.error?.mensaje ??
            'No se pudieron cargar los alumnos del curso.';

          this.cargando = false;

          this.cdr.detectChanges();
        }

      });
  }

  buscar(): void {

    const texto = this.busqueda
      .trim()
      .toLowerCase();

    if (!texto) {
      this.alumnosFiltrados = this.alumnos;
      return;
    }

    this.alumnosFiltrados =
      this.alumnos.filter(alumno =>
        alumno.nombreCompleto
          .toLowerCase()
          .includes(texto) ||

        alumno.username
          .toLowerCase()
          .includes(texto) ||

        alumno.telefono
          ?.toLowerCase()
          .includes(texto)
      );
  }

  registrarNota(alumno: Alumno): void {

    this.router.navigate([
      '/docente/curso',
      this.idCurso,
      'alumno',
      alumno.idAlumno,
      'nota'
    ]);
  }

  verNotasCurso(): void {

  this.router.navigate([
    '/docente/curso',
    this.idCurso,
    'notas'
  ]);
}
}