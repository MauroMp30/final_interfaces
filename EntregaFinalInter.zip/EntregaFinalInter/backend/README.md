# Backend - IDAT Cursos

Backend Spring Boot para gestion academica simplificada.

## Requisitos

- Java 21
- IntelliJ IDEA
- MySQL en ejecucion

## Configurar MySQL

El proyecto intenta crear la base de datos automaticamente con:

```properties
createDatabaseIfNotExist=true
```

Configuracion actual:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/idat_cursos_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=America/Lima&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=admin
```

Si tu MySQL tiene otra clave, cambia `spring.datasource.password` en:

```text
src/main/resources/application.properties
```

Hibernate crea/actualiza las tablas con:

```properties
spring.jpa.hibernate.ddl-auto=update
```

## Ejecutar

1. Abrir esta carpeta `backend` en IntelliJ.
2. Esperar que Maven descargue dependencias.
3. Ejecutar `CursosApplication`.
4. Probar en `http://localhost:8080`.

## Usuarios de prueba

Todos usan la clave:

```text
123456
```

```text
admin    -> ADMIN
docente  -> DOCENTE
alumno   -> ESTUDIANTE
```

## Login

POST:

```text
http://localhost:8080/api/auth/login
```

Body:

```json
{
  "username": "admin",
  "password": "123456"
}
```

Respuesta:

```json
{
  "token": "jwt...",
  "username": "admin",
  "rol": "ADMIN"
}
```

Para consumir endpoints protegidos, enviar el header:

```text
Authorization: Bearer TU_TOKEN
```

## Endpoints principales

```text
POST /api/auth/login                PUBLICO

GET  /api/cursos                    ADMIN, DOCENTE, ESTUDIANTE
POST /api/cursos                    ADMIN

GET  /api/admin/usuarios            ADMIN
GET  /api/admin/docentes            ADMIN
GET  /api/admin/alumnos             ADMIN
GET  /api/admin/secciones           ADMIN
GET  /api/admin/asignaciones        ADMIN
POST /api/admin/asignaciones        ADMIN
GET  /api/admin/matriculas          ADMIN
POST /api/admin/matriculas          ADMIN

GET  /api/docente/mis-cursos        DOCENTE

GET  /api/alumno/mis-cursos         ESTUDIANTE

GET  /api/notas/mis-notas           ESTUDIANTE
GET  /api/notas/curso/{idCurso}     ADMIN, DOCENTE
POST /api/notas                     ADMIN, DOCENTE
```

## Como probar por rol

### 1. Login como ADMIN

Body:

```json
{
  "username": "admin",
  "password": "123456"
}
```

Con el token de ADMIN prueba:

```text
GET  http://localhost:8080/api/admin/usuarios
GET  http://localhost:8080/api/admin/docentes
GET  http://localhost:8080/api/admin/alumnos
GET  http://localhost:8080/api/admin/secciones
GET  http://localhost:8080/api/admin/asignaciones
GET  http://localhost:8080/api/admin/matriculas
GET  http://localhost:8080/api/cursos
POST http://localhost:8080/api/cursos
POST http://localhost:8080/api/admin/asignaciones
POST http://localhost:8080/api/admin/matriculas
GET  http://localhost:8080/api/notas/curso/1
POST http://localhost:8080/api/notas
```

ADMIN no deberia entrar a:

```text
GET http://localhost:8080/api/docente/mis-cursos
GET http://localhost:8080/api/alumno/mis-cursos
GET http://localhost:8080/api/notas/mis-notas
```

Es normal que esos endpoints retornen `403 Forbidden` con token de ADMIN, porque son endpoints personales de DOCENTE o ESTUDIANTE.

### 2. Login como DOCENTE

Body:

```json
{
  "username": "docente",
  "password": "123456"
}
```

Con el token de DOCENTE prueba:

```text
GET  http://localhost:8080/api/cursos
GET  http://localhost:8080/api/docente/mis-cursos
GET  http://localhost:8080/api/notas/curso/1
POST http://localhost:8080/api/notas
```

DOCENTE no deberia poder crear cursos ni usar endpoints de ADMIN.

### 3. Login como ESTUDIANTE

Body:

```json
{
  "username": "alumno",
  "password": "123456"
}
```

Con el token de ESTUDIANTE prueba:

```text
GET http://localhost:8080/api/cursos
GET http://localhost:8080/api/alumno/mis-cursos
GET http://localhost:8080/api/notas/mis-notas
```

ESTUDIANTE no deberia poder crear cursos, registrar notas ni usar endpoints de ADMIN/DOCENTE.

## Crear curso

POST:

```text
http://localhost:8080/api/cursos
```

Body:

```json
{
  "nombre": "Base de Datos",
  "descripcion": "Curso de MySQL",
  "creditos": 3,
  "idSeccion": 1
}
```

## Asignar curso a docente

Solo ADMIN.

POST:

```text
http://localhost:8080/api/admin/asignaciones
```

Body:

```json
{
  "idDocente": 1,
  "idCurso": 1
}
```

## Matricular alumno en seccion

Solo ADMIN.

POST:

```text
http://localhost:8080/api/admin/matriculas
```

Body:

```json
{
  "idAlumno": 1,
  "idSeccion": 1
}
```

## Registrar nota

POST:

```text
http://localhost:8080/api/notas
```

Body:

```json
{
  "idCurso": 1,
  "idAlumno": 1,
  "nombreEvaluacion": "Examen Parcial",
  "calificacion": 18.00,
  "ponderacion": 40.00
}
```
