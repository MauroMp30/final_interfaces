package com.idat.cursos.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record CursoRequest(
        @NotBlank String nombre,
        String descripcion,
        @NotNull @Min(1) Integer creditos,
        Integer idSeccion
) {
}
