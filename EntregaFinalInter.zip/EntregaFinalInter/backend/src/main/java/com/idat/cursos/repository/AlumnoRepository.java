package com.idat.cursos.repository;

import com.idat.cursos.model.Alumno;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlumnoRepository extends JpaRepository<Alumno, Integer> {
    Optional<Alumno> findByUsuarioUsername(String username);
}
