package com.idat.cursos.dto;

import com.idat.cursos.model.Curso;

public record CursoResponse(
        Integer idCurso,
        String nombre,
        String descripcion,
        Integer creditos,
        Boolean estado,
        String seccion
) {
    public static CursoResponse from(Curso curso) {
        String nombreSeccion = curso.getSeccion() == null ? null : curso.getSeccion().getNombreSeccion();
        return new CursoResponse(
                curso.getIdCurso(),
                curso.getNombre(),
                curso.getDescripcion(),
                curso.getCreditos(),
                curso.getEstado(),
                nombreSeccion
        );
    }
}
