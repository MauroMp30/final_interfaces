package com.idat.cursos.dto;

import jakarta.validation.constraints.NotNull;

public record AsignacionRequest(
        @NotNull Integer idDocente,
        @NotNull Integer idCurso
) {
}
