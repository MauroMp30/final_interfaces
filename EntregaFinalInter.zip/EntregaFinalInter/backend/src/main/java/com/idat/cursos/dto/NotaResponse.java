package com.idat.cursos.dto;

import com.idat.cursos.model.NotaCurso;
import java.math.BigDecimal;

public record NotaResponse(
        Integer idNota,
        String curso,
        String alumno,
        String nombreEvaluacion,
        BigDecimal calificacion,
        BigDecimal ponderacion
) {
    public static NotaResponse from(NotaCurso nota) {
        String nombreAlumno = nota.getAlumno().getUsuario().getNombre()
                + " "
                + nota.getAlumno().getUsuario().getApellido();

        return new NotaResponse(
                nota.getIdNota(),
                nota.getCurso().getNombre(),
                nombreAlumno,
                nota.getNombreEvaluacion(),
                nota.getCalificacion(),
                nota.getPonderacion()
        );
    }
}
