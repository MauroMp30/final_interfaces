package com.idat.cursos.service;

import com.idat.cursos.dto.AlumnoResponse;
import com.idat.cursos.dto.AsignacionRequest;
import com.idat.cursos.dto.AsignacionResponse;
import com.idat.cursos.dto.DocenteResponse;
import com.idat.cursos.dto.MatriculaRequest;
import com.idat.cursos.dto.MatriculaResponse;
import com.idat.cursos.dto.SeccionResponse;
import com.idat.cursos.dto.UsuarioRequest;
import com.idat.cursos.dto.UsuarioResponse;
import com.idat.cursos.model.Alumno;
import com.idat.cursos.model.AsignacionCurso;
import com.idat.cursos.model.Curso;
import com.idat.cursos.model.Docente;
import com.idat.cursos.model.Matricula;
import com.idat.cursos.model.Rol;
import com.idat.cursos.model.Seccion;
import com.idat.cursos.model.Usuario;
import com.idat.cursos.repository.AlumnoRepository;
import com.idat.cursos.repository.AsignacionCursoRepository;
import com.idat.cursos.repository.CursoRepository;
import com.idat.cursos.repository.DocenteRepository;
import com.idat.cursos.repository.MatriculaRepository;
import com.idat.cursos.repository.RolRepository;
import com.idat.cursos.repository.SeccionRepository;
import com.idat.cursos.repository.UsuarioRepository;
import java.util.List;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    private final UsuarioRepository usuarioRepository;
    private final DocenteRepository docenteRepository;
    private final AlumnoRepository alumnoRepository;
    private final SeccionRepository seccionRepository;
    private final CursoRepository cursoRepository;
    private final AsignacionCursoRepository asignacionCursoRepository;
    private final MatriculaRepository matriculaRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminService(
            UsuarioRepository usuarioRepository,
            DocenteRepository docenteRepository,
            AlumnoRepository alumnoRepository,
            SeccionRepository seccionRepository,
            CursoRepository cursoRepository,
            AsignacionCursoRepository asignacionCursoRepository,
            MatriculaRepository matriculaRepository,
            RolRepository rolRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.usuarioRepository = usuarioRepository;
        this.docenteRepository = docenteRepository;
        this.alumnoRepository = alumnoRepository;
        this.seccionRepository = seccionRepository;
        this.cursoRepository = cursoRepository;
        this.asignacionCursoRepository = asignacionCursoRepository;
        this.matriculaRepository = matriculaRepository;
        this.rolRepository = rolRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<UsuarioResponse> listarUsuarios() {
        return usuarioRepository.findAll()
                .stream()
                .map(UsuarioResponse::from)
                .toList();
    }

    public UsuarioResponse crearUsuario(UsuarioRequest request) {

        if (usuarioRepository.existsByUsername(request.username())) {
            throw new IllegalArgumentException(
                    "El username ya está registrado"
            );
        }

        if (usuarioRepository.existsByEmail(request.email())) {
            throw new IllegalArgumentException(
                    "El email ya está registrado"
            );
        }

        String rolNombre = request.rol()
                .trim()
                .toUpperCase();

        if (!rolNombre.equals("ADMIN")
                && !rolNombre.equals("DOCENTE")
                && !rolNombre.equals("ESTUDIANTE")) {

            throw new IllegalArgumentException(
                    "Rol inválido. Los roles permitidos son ADMIN, DOCENTE y ESTUDIANTE"
            );
        }

        Rol rol = rolRepository.findByNombreRol(rolNombre)
                .orElseThrow(() ->
                        new IllegalArgumentException("El rol no existe")
                );

        Usuario usuario = new Usuario();

        usuario.setUsername(request.username().trim());
        usuario.setPasswordHash(
                passwordEncoder.encode(request.password())
        );
        usuario.setDni(request.dni().trim());
        usuario.setNombre(request.nombre().trim());
        usuario.setApellido(request.apellido().trim());
        usuario.setEmail(request.email().trim());
        usuario.setRol(rol);
        usuario.setEstado(true);

        usuario = usuarioRepository.save(usuario);

        if (rolNombre.equals("DOCENTE")) {

            Docente docente = new Docente();

            docente.setUsuario(usuario);
            docente.setEspecialidad(request.especialidad());
            docente.setGradoAcademico(request.gradoAcademico());
            docente.setTelefono(request.telefono());

            docenteRepository.save(docente);

        } else if (rolNombre.equals("ESTUDIANTE")) {

            Alumno alumno = new Alumno();

            alumno.setUsuario(usuario);
            alumno.setDniApoderado(request.dniApoderado());
            alumno.setTelefono(request.telefono());
            alumno.setFechaNacimiento(request.fechaNacimiento());

            alumnoRepository.save(alumno);
        }

        return UsuarioResponse.from(usuario);
    }

    public List<DocenteResponse> listarDocentes() {
        return docenteRepository.findAll()
                .stream()
                .map(DocenteResponse::from)
                .toList();
    }

    public List<AlumnoResponse> listarAlumnos() {
        return alumnoRepository.findAll()
                .stream()
                .map(AlumnoResponse::from)
                .toList();
    }

    public List<SeccionResponse> listarSecciones() {
        return seccionRepository.findAll()
                .stream()
                .map(SeccionResponse::from)
                .toList();
    }

    public List<AsignacionResponse> listarAsignaciones() {
        return asignacionCursoRepository.findAll()
                .stream()
                .map(AsignacionResponse::from)
                .toList();
    }

    public AsignacionResponse asignarCurso(AsignacionRequest request) {

        Docente docente = docenteRepository.findById(request.idDocente())
                .orElseThrow(() ->
                        new IllegalArgumentException("Docente no encontrado")
                );

        Curso curso = cursoRepository.findById(request.idCurso())
                .orElseThrow(() ->
                        new IllegalArgumentException("Curso no encontrado")
                );

        AsignacionCurso asignacion = new AsignacionCurso();

        asignacion.setDocente(docente);
        asignacion.setCurso(curso);
        asignacion.setEstado(true);

        return AsignacionResponse.from(
                asignacionCursoRepository.save(asignacion)
        );
    }

    public List<MatriculaResponse> listarMatriculas() {
        return matriculaRepository.findAll()
                .stream()
                .map(MatriculaResponse::from)
                .toList();
    }

    public MatriculaResponse matricularAlumno(
            MatriculaRequest request
    ) {

        Alumno alumno = alumnoRepository.findById(request.idAlumno())
                .orElseThrow(() ->
                        new IllegalArgumentException("Alumno no encontrado")
                );

        Seccion seccion = seccionRepository.findById(request.idSeccion())
                .orElseThrow(() ->
                        new IllegalArgumentException("Seccion no encontrada")
                );

        Matricula matricula = new Matricula();

        matricula.setAlumno(alumno);
        matricula.setSeccion(seccion);
        matricula.setEstado(true);

        return MatriculaResponse.from(
                matriculaRepository.save(matricula)
        );
    }
}