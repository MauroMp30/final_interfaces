package com.idat.cursos.repository;

import com.idat.cursos.model.Matricula;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatriculaRepository extends JpaRepository<Matricula, Integer> {

    List<Matricula> findByAlumnoUsuarioUsernameAndEstadoTrue(String username);

    List<Matricula> findBySeccionIdSeccionAndEstadoTrue(Integer idSeccion);
}