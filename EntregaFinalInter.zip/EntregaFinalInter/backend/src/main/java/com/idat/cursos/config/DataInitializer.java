package com.idat.cursos.config;

import com.idat.cursos.model.Alumno;
import com.idat.cursos.model.AsignacionCurso;
import com.idat.cursos.model.Curso;
import com.idat.cursos.model.Docente;
import com.idat.cursos.model.Matricula;
import com.idat.cursos.model.NotaCurso;
import com.idat.cursos.model.Rol;
import com.idat.cursos.model.Seccion;
import com.idat.cursos.model.Usuario;
import com.idat.cursos.repository.AlumnoRepository;
import com.idat.cursos.repository.AsignacionCursoRepository;
import com.idat.cursos.repository.CursoRepository;
import com.idat.cursos.repository.DocenteRepository;
import com.idat.cursos.repository.MatriculaRepository;
import com.idat.cursos.repository.NotaCursoRepository;
import com.idat.cursos.repository.RolRepository;
import com.idat.cursos.repository.SeccionRepository;
import com.idat.cursos.repository.UsuarioRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initData(
            RolRepository rolRepository,
            UsuarioRepository usuarioRepository,
            DocenteRepository docenteRepository,
            AlumnoRepository alumnoRepository,
            SeccionRepository seccionRepository,
            CursoRepository cursoRepository,
            AsignacionCursoRepository asignacionCursoRepository,
            MatriculaRepository matriculaRepository,
            NotaCursoRepository notaCursoRepository,
            PasswordEncoder passwordEncoder
    ) {
        return args -> {
            Rol adminRol = crearRolSiNoExiste(rolRepository, "ADMIN", "Acceso total al sistema");
            Rol docenteRol = crearRolSiNoExiste(rolRepository, "DOCENTE", "Gestiona cursos asignados y notas");
            Rol estudianteRol = crearRolSiNoExiste(rolRepository, "ESTUDIANTE", "Consulta cursos y notas");

            Usuario admin = crearUsuarioSiNoExiste(
                    usuarioRepository,
                    passwordEncoder,
                    "admin",
                    "123456",
                    "00000001",
                    "Administrador",
                    "IDAT",
                    "admin@idat.edu.pe",
                    adminRol
            );

            Usuario docenteUsuario = crearUsuarioSiNoExiste(
                    usuarioRepository,
                    passwordEncoder,
                    "docente",
                    "123456",
                    "00000002",
                    "Carlos",
                    "Ramirez",
                    "docente@idat.edu.pe",
                    docenteRol
            );

            Usuario alumnoUsuario = crearUsuarioSiNoExiste(
                    usuarioRepository,
                    passwordEncoder,
                    "alumno",
                    "123456",
                    "00000003",
                    "Lucia",
                    "Torres",
                    "alumno@idat.edu.pe",
                    estudianteRol
            );

            Docente docente = docenteRepository.findByUsuarioUsername("docente")
                    .orElseGet(() -> {
                        Docente nuevo = new Docente();
                        nuevo.setUsuario(docenteUsuario);
                        nuevo.setEspecialidad("Desarrollo de Software");
                        nuevo.setGradoAcademico("Ingeniero");
                        nuevo.setTelefono("999888777");
                        return docenteRepository.save(nuevo);
                    });

            Alumno alumno = alumnoRepository.findByUsuarioUsername("alumno")
                    .orElseGet(() -> {
                        Alumno nuevo = new Alumno();
                        nuevo.setUsuario(alumnoUsuario);
                        nuevo.setDniApoderado("11111111");
                        nuevo.setTelefono("988777666");
                        nuevo.setFechaNacimiento(LocalDate.of(2005, 5, 10));
                        return alumnoRepository.save(nuevo);
                    });

            if (seccionRepository.count() == 0) {
                Seccion seccion = new Seccion();
                seccion.setNombreSeccion("DSW-01");
                seccion.setPeriodoAcademico("2026-I");
                seccion.setCapacidadMaxima(30);
                seccion.setEstado(true);
                seccion = seccionRepository.save(seccion);

                Curso curso = new Curso();
                curso.setSeccion(seccion);
                curso.setNombre("Desarrollo Web Full Stack");
                curso.setDescripcion("Curso de Spring Boot y Angular");
                curso.setCreditos(4);
                curso.setEstado(true);
                curso = cursoRepository.save(curso);

                AsignacionCurso asignacion = new AsignacionCurso();
                asignacion.setDocente(docente);
                asignacion.setCurso(curso);
                asignacion.setEstado(true);
                asignacionCursoRepository.save(asignacion);

                Matricula matricula = new Matricula();
                matricula.setAlumno(alumno);
                matricula.setSeccion(seccion);
                matricula.setEstado(true);
                matriculaRepository.save(matricula);

                NotaCurso nota = new NotaCurso();
                nota.setAlumno(alumno);
                nota.setCurso(curso);
                nota.setNombreEvaluacion("Practica 1");
                nota.setCalificacion(new BigDecimal("17.50"));
                nota.setPonderacion(new BigDecimal("30.00"));
                notaCursoRepository.save(nota);
            }

            admin.getUsername();
        };
    }

    private Rol crearRolSiNoExiste(RolRepository rolRepository, String nombre, String descripcion) {
        return rolRepository.findByNombreRol(nombre)
                .orElseGet(() -> rolRepository.save(new Rol(null, nombre, descripcion)));
    }

    private Usuario crearUsuarioSiNoExiste(
            UsuarioRepository usuarioRepository,
            PasswordEncoder passwordEncoder,
            String username,
            String password,
            String dni,
            String nombre,
            String apellido,
            String email,
            Rol rol
    ) {
        return usuarioRepository.findByUsername(username)
                .orElseGet(() -> {
                    Usuario usuario = new Usuario();
                    usuario.setUsername(username);
                    usuario.setPasswordHash(passwordEncoder.encode(password));
                    usuario.setDni(dni);
                    usuario.setNombre(nombre);
                    usuario.setApellido(apellido);
                    usuario.setEmail(email);
                    usuario.setRol(rol);
                    usuario.setEstado(true);
                    return usuarioRepository.save(usuario);
                });
    }
}
