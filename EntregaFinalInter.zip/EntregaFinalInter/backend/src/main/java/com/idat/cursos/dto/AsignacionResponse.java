package com.idat.cursos.dto;

import com.idat.cursos.model.AsignacionCurso;
import java.time.LocalDateTime;

public record AsignacionResponse(
        Integer idAsignacion,
        String docente,
        String curso,
        Boolean estado,
        LocalDateTime fechaAsignacion
) {
    public static AsignacionResponse from(AsignacionCurso asignacion) {
        String docente = asignacion.getDocente().getUsuario().getNombre()
                + " "
                + asignacion.getDocente().getUsuario().getApellido();

        return new AsignacionResponse(
                asignacion.getIdAsignacion(),
                docente,
                asignacion.getCurso().getNombre(),
                asignacion.getEstado(),
                asignacion.getFechaAsignacion()
        );
    }
}
