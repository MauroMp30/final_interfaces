package com.idat.cursos.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public record NotaRequest(
        @NotNull Integer idCurso,
        @NotNull Integer idAlumno,
        @NotBlank String nombreEvaluacion,
        @NotNull @DecimalMin("0.00") @DecimalMax("20.00") BigDecimal calificacion,
        @NotNull @DecimalMin("0.00") @DecimalMax("100.00") BigDecimal ponderacion
) {
}
