package com.idat.cursos.repository;

import com.idat.cursos.model.AsignacionCurso;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AsignacionCursoRepository extends JpaRepository<AsignacionCurso, Integer> {

    List<AsignacionCurso> findByDocenteUsuarioUsernameAndEstadoTrue(String username);

    Optional<AsignacionCurso> findByDocenteUsuarioUsernameAndCursoIdCursoAndEstadoTrue(
            String username,
            Integer idCurso
    );
}