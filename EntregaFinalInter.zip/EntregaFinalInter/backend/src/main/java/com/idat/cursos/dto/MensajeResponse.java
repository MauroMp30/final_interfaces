package com.idat.cursos.dto;

import java.util.Map;

public record MensajeResponse(
        String mensaje,
        Map<String, String> errores
) {

    public MensajeResponse(String mensaje) {
        this(mensaje, null);
    }
}