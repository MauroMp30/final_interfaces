package com.idat.cursos.service;

import com.idat.cursos.dto.CursoResponse;
import com.idat.cursos.repository.CursoRepository;
import com.idat.cursos.repository.MatriculaRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class AlumnoService {

    private final MatriculaRepository matriculaRepository;
    private final CursoRepository cursoRepository;

    public AlumnoService(MatriculaRepository matriculaRepository, CursoRepository cursoRepository) {
        this.matriculaRepository = matriculaRepository;
        this.cursoRepository = cursoRepository;
    }

    public List<CursoResponse> listarMisCursos(String username) {
        return matriculaRepository.findByAlumnoUsuarioUsernameAndEstadoTrue(username)
                .stream()
                .flatMap(matricula -> cursoRepository
                        .findBySeccionIdSeccionAndEstadoTrue(matricula.getSeccion().getIdSeccion())
                        .stream())
                .map(CursoResponse::from)
                .toList();
    }
}
