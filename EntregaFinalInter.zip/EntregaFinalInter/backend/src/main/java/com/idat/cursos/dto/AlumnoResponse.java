package com.idat.cursos.dto;

import com.idat.cursos.model.Alumno;
import java.time.LocalDate;

public record AlumnoResponse(
        Integer idAlumno,
        String username,
        String nombreCompleto,
        String dniApoderado,
        String telefono,
        LocalDate fechaNacimiento
) {
    public static AlumnoResponse from(Alumno alumno) {
        return new AlumnoResponse(
                alumno.getIdAlumno(),
                alumno.getUsuario().getUsername(),
                alumno.getUsuario().getNombre() + " " + alumno.getUsuario().getApellido(),
                alumno.getDniApoderado(),
                alumno.getTelefono(),
                alumno.getFechaNacimiento()
        );
    }
}
