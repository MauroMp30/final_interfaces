package com.idat.cursos.dto;

import com.idat.cursos.model.Usuario;

public record UsuarioResponse(
        Integer idUsuario,
        String username,
        String dni,
        String nombre,
        String apellido,
        String email,
        String rol,
        Boolean estado
) {
    public static UsuarioResponse from(Usuario usuario) {
        return new UsuarioResponse(
                usuario.getIdUsuario(),
                usuario.getUsername(),
                usuario.getDni(),
                usuario.getNombre(),
                usuario.getApellido(),
                usuario.getEmail(),
                usuario.getRol().getNombreRol(),
                usuario.getEstado()
        );
    }
}
