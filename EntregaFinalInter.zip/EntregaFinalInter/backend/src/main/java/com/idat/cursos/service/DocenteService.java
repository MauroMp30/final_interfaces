package com.idat.cursos.service;

import com.idat.cursos.dto.AlumnoResponse;
import com.idat.cursos.dto.CursoResponse;
import com.idat.cursos.model.AsignacionCurso;
import com.idat.cursos.repository.AsignacionCursoRepository;
import com.idat.cursos.repository.MatriculaRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class DocenteService {

    private final AsignacionCursoRepository asignacionCursoRepository;
    private final MatriculaRepository matriculaRepository;

    public DocenteService(
            AsignacionCursoRepository asignacionCursoRepository,
            MatriculaRepository matriculaRepository
    ) {
        this.asignacionCursoRepository = asignacionCursoRepository;
        this.matriculaRepository = matriculaRepository;
    }

    public List<CursoResponse> listarMisCursos(String username) {
        return asignacionCursoRepository
                .findByDocenteUsuarioUsernameAndEstadoTrue(username)
                .stream()
                .map(asignacion -> CursoResponse.from(asignacion.getCurso()))
                .toList();
    }

    public List<AlumnoResponse> listarAlumnosPorCurso(String username, Integer idCurso) {

        AsignacionCurso asignacion = asignacionCursoRepository
                .findByDocenteUsuarioUsernameAndCursoIdCursoAndEstadoTrue(username, idCurso)
                .orElseThrow(() -> new IllegalArgumentException(
                        "El curso no pertenece al docente"
                ));

        Integer idSeccion = asignacion.getCurso().getSeccion().getIdSeccion();

        return matriculaRepository
                .findBySeccionIdSeccionAndEstadoTrue(idSeccion)
                .stream()
                .map(matricula -> AlumnoResponse.from(matricula.getAlumno()))
                .toList();
    }
}