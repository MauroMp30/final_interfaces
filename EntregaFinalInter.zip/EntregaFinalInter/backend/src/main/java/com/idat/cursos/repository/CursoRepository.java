package com.idat.cursos.repository;

import com.idat.cursos.model.Curso;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoRepository extends JpaRepository<Curso, Integer> {
    List<Curso> findByEstadoTrue();
    List<Curso> findBySeccionIdSeccionAndEstadoTrue(Integer idSeccion);
}
