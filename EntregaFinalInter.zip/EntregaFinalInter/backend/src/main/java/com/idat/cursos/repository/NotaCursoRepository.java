package com.idat.cursos.repository;

import com.idat.cursos.model.NotaCurso;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotaCursoRepository extends JpaRepository<NotaCurso, Integer> {
    List<NotaCurso> findByAlumnoUsuarioUsername(String username);
    List<NotaCurso> findByCursoIdCurso(Integer idCurso);
}
