package com.idat.cursos.service;

import com.idat.cursos.dto.NotaRequest;
import com.idat.cursos.dto.NotaResponse;
import com.idat.cursos.model.Alumno;
import com.idat.cursos.model.Curso;
import com.idat.cursos.model.NotaCurso;
import com.idat.cursos.repository.AlumnoRepository;
import com.idat.cursos.repository.CursoRepository;
import com.idat.cursos.repository.NotaCursoRepository;
import java.util.List;
import com.idat.cursos.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import com.idat.cursos.model.Usuario;
import com.idat.cursos.repository.AsignacionCursoRepository;
import com.idat.cursos.repository.MatriculaRepository;


@Service
public class NotaService {

    private final NotaCursoRepository notaCursoRepository;
    private final CursoRepository cursoRepository;
    private final AlumnoRepository alumnoRepository;
    private final UsuarioRepository usuarioRepository;
    private final AsignacionCursoRepository asignacionCursoRepository;
    private final MatriculaRepository matriculaRepository;


    public NotaService(
            NotaCursoRepository notaCursoRepository,
            CursoRepository cursoRepository,
            AlumnoRepository alumnoRepository,
            UsuarioRepository usuarioRepository,
            AsignacionCursoRepository asignacionCursoRepository,
            MatriculaRepository matriculaRepository
    ) {
        this.notaCursoRepository = notaCursoRepository;
        this.cursoRepository = cursoRepository;
        this.alumnoRepository = alumnoRepository;
        this.usuarioRepository = usuarioRepository;
        this.asignacionCursoRepository = asignacionCursoRepository;
        this.matriculaRepository = matriculaRepository;
    }

    public NotaResponse registrar(NotaRequest request, String username) {

        Usuario usuario = usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Usuario no encontrado"
                ));

        Curso curso = cursoRepository.findById(request.idCurso())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Curso no encontrado"
                ));

        Alumno alumno = alumnoRepository.findById(request.idAlumno())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Alumno no encontrado"
                ));

        String rol = usuario.getRol().getNombreRol();

        if ("DOCENTE".equals(rol)) {

            boolean tieneCurso = asignacionCursoRepository
                    .findByDocenteUsuarioUsernameAndCursoIdCursoAndEstadoTrue(
                            username,
                            request.idCurso()
                    )
                    .isPresent();

            if (!tieneCurso) {
                throw new IllegalArgumentException(
                        "No puedes registrar notas en un curso que no tienes asignado"
                );
            }
        }

        Integer idSeccion = curso.getSeccion() == null
                ? null
                : curso.getSeccion().getIdSeccion();

        if (idSeccion == null) {
            throw new IllegalArgumentException(
                    "El curso no tiene una sección asignada"
            );
        }

        boolean alumnoMatriculado = matriculaRepository
                .findBySeccionIdSeccionAndEstadoTrue(idSeccion)
                .stream()
                .anyMatch(matricula ->
                        matricula.getAlumno().getIdAlumno().equals(request.idAlumno())
                );

        if (!alumnoMatriculado) {
            throw new IllegalArgumentException(
                    "El alumno no está matriculado en este curso"
            );
        }

        NotaCurso nota = new NotaCurso();
        nota.setCurso(curso);
        nota.setAlumno(alumno);
        nota.setNombreEvaluacion(request.nombreEvaluacion());
        nota.setCalificacion(request.calificacion());
        nota.setPonderacion(request.ponderacion());

        return NotaResponse.from(notaCursoRepository.save(nota));
    }

    public List<NotaResponse> listarMisNotas(String username) {
        return notaCursoRepository.findByAlumnoUsuarioUsername(username)
                .stream()
                .map(NotaResponse::from)
                .toList();
    }

    public List<NotaResponse> listarPorCurso(Integer idCurso) {
        return notaCursoRepository.findByCursoIdCurso(idCurso)
                .stream()
                .map(NotaResponse::from)
                .toList();
    }
}
