package com.idat.cursos.service;

import com.idat.cursos.dto.CursoRequest;
import com.idat.cursos.dto.CursoResponse;
import com.idat.cursos.model.Curso;
import com.idat.cursos.model.Seccion;
import com.idat.cursos.repository.CursoRepository;
import com.idat.cursos.repository.SeccionRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class CursoService {

    private final CursoRepository cursoRepository;
    private final SeccionRepository seccionRepository;

    public CursoService(CursoRepository cursoRepository, SeccionRepository seccionRepository) {
        this.cursoRepository = cursoRepository;
        this.seccionRepository = seccionRepository;
    }

    public List<CursoResponse> listarActivos() {
        return cursoRepository.findByEstadoTrue()
                .stream()
                .map(CursoResponse::from)
                .toList();
    }

    public CursoResponse crear(CursoRequest request) {
        Curso curso = new Curso();
        curso.setNombre(request.nombre());
        curso.setDescripcion(request.descripcion());
        curso.setCreditos(request.creditos());
        curso.setEstado(true);

        if (request.idSeccion() != null) {
            Seccion seccion = seccionRepository.findById(request.idSeccion())
                    .orElseThrow(() -> new IllegalArgumentException("Seccion no encontrada"));
            curso.setSeccion(seccion);
        }

        return CursoResponse.from(cursoRepository.save(curso));
    }
}
