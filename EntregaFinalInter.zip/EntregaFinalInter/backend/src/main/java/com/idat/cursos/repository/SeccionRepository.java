package com.idat.cursos.repository;

import com.idat.cursos.model.Seccion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeccionRepository extends JpaRepository<Seccion, Integer> {
}
