package com.idat.cursos.dto;

import com.idat.cursos.model.Seccion;

public record SeccionResponse(
        Integer idSeccion,
        String nombreSeccion,
        String periodoAcademico,
        Integer capacidadMaxima,
        Boolean estado
) {
    public static SeccionResponse from(Seccion seccion) {
        return new SeccionResponse(
                seccion.getIdSeccion(),
                seccion.getNombreSeccion(),
                seccion.getPeriodoAcademico(),
                seccion.getCapacidadMaxima(),
                seccion.getEstado()
        );
    }
}
