package com.idat.cursos.controller;

import com.idat.cursos.dto.AlumnoResponse;
import com.idat.cursos.dto.CursoResponse;
import com.idat.cursos.service.DocenteService;
import java.security.Principal;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/docente")
@PreAuthorize("hasRole('DOCENTE')")
public class DocenteController {

    private final DocenteService docenteService;

    public DocenteController(DocenteService docenteService) {
        this.docenteService = docenteService;
    }

    @GetMapping("/mis-cursos")
    public ResponseEntity<List<CursoResponse>> misCursos(Principal principal) {
        return ResponseEntity.ok(
                docenteService.listarMisCursos(principal.getName())
        );
    }

    @GetMapping("/curso/{idCurso}/alumnos")
    public ResponseEntity<List<AlumnoResponse>> alumnosPorCurso(
            @PathVariable Integer idCurso,
            Principal principal
    ) {
        return ResponseEntity.ok(
                docenteService.listarAlumnosPorCurso(
                        principal.getName(),
                        idCurso
                )
        );
    }
}