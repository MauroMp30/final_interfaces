package com.idat.cursos.dto;

import com.idat.cursos.model.Matricula;
import java.time.LocalDate;

public record MatriculaResponse(
        Integer idMatricula,
        String alumno,
        String seccion,
        LocalDate fechaMatricula,
        Boolean estado
) {
    public static MatriculaResponse from(Matricula matricula) {
        String alumno = matricula.getAlumno().getUsuario().getNombre()
                + " "
                + matricula.getAlumno().getUsuario().getApellido();

        return new MatriculaResponse(
                matricula.getIdMatricula(),
                alumno,
                matricula.getSeccion().getNombreSeccion(),
                matricula.getFechaMatricula(),
                matricula.getEstado()
        );
    }
}
