package com.idat.cursos.controller;

import com.idat.cursos.dto.NotaRequest;
import com.idat.cursos.dto.NotaResponse;
import com.idat.cursos.service.NotaService;
import jakarta.validation.Valid;
import java.security.Principal;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/notas")
public class NotaController {

    private final NotaService notaService;

    public NotaController(NotaService notaService) {
        this.notaService = notaService;
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCENTE')")
    public ResponseEntity<NotaResponse> registrar(
            @Valid @RequestBody NotaRequest request,
            Principal principal
    ) {
        return ResponseEntity.ok(
                notaService.registrar(request, principal.getName())
        );
    }

    @GetMapping("/mis-notas")
    @PreAuthorize("hasRole('ESTUDIANTE')")
    public ResponseEntity<List<NotaResponse>> misNotas(Principal principal) {
        return ResponseEntity.ok(notaService.listarMisNotas(principal.getName()));
    }

    @GetMapping("/curso/{idCurso}")
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCENTE')")
    public ResponseEntity<List<NotaResponse>> notasPorCurso(
            @PathVariable Integer idCurso
    ) {
        return ResponseEntity.ok(notaService.listarPorCurso(idCurso));
    }
}