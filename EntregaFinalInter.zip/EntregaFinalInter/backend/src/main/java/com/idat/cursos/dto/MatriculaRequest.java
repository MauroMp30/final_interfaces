package com.idat.cursos.dto;

import jakarta.validation.constraints.NotNull;

public record MatriculaRequest(
        @NotNull Integer idAlumno,
        @NotNull Integer idSeccion
) {
}
