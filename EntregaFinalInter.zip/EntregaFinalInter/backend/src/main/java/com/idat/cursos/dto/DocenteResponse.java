package com.idat.cursos.dto;

import com.idat.cursos.model.Docente;

public record DocenteResponse(
        Integer idDocente,
        String username,
        String nombreCompleto,
        String especialidad,
        String gradoAcademico,
        String telefono
) {
    public static DocenteResponse from(Docente docente) {
        return new DocenteResponse(
                docente.getIdDocente(),
                docente.getUsuario().getUsername(),
                docente.getUsuario().getNombre() + " " + docente.getUsuario().getApellido(),
                docente.getEspecialidad(),
                docente.getGradoAcademico(),
                docente.getTelefono()
        );
    }
}
