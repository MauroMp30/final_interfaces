package com.idat.cursos.controller;

import com.idat.cursos.dto.AlumnoResponse;
import com.idat.cursos.dto.AsignacionRequest;
import com.idat.cursos.dto.AsignacionResponse;
import com.idat.cursos.dto.DocenteResponse;
import com.idat.cursos.dto.MatriculaRequest;
import com.idat.cursos.dto.MatriculaResponse;
import com.idat.cursos.dto.SeccionResponse;
import com.idat.cursos.dto.UsuarioRequest;
import com.idat.cursos.dto.UsuarioResponse;
import com.idat.cursos.service.AdminService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/usuarios")
    public ResponseEntity<List<UsuarioResponse>> usuarios() {
        return ResponseEntity.ok(adminService.listarUsuarios());
    }

    @PostMapping("/usuarios")
    public ResponseEntity<UsuarioResponse> crearUsuario(
            @Valid @RequestBody UsuarioRequest request
    ) {
        return ResponseEntity.ok(adminService.crearUsuario(request));
    }

    @GetMapping("/docentes")
    public ResponseEntity<List<DocenteResponse>> docentes() {
        return ResponseEntity.ok(adminService.listarDocentes());
    }

    @GetMapping("/alumnos")
    public ResponseEntity<List<AlumnoResponse>> alumnos() {
        return ResponseEntity.ok(adminService.listarAlumnos());
    }

    @GetMapping("/secciones")
    public ResponseEntity<List<SeccionResponse>> secciones() {
        return ResponseEntity.ok(adminService.listarSecciones());
    }

    @GetMapping("/asignaciones")
    public ResponseEntity<List<AsignacionResponse>> asignaciones() {
        return ResponseEntity.ok(adminService.listarAsignaciones());
    }

    @PostMapping("/asignaciones")
    public ResponseEntity<AsignacionResponse> asignarCurso(
            @Valid @RequestBody AsignacionRequest request
    ) {
        return ResponseEntity.ok(adminService.asignarCurso(request));
    }

    @GetMapping("/matriculas")
    public ResponseEntity<List<MatriculaResponse>> matriculas() {
        return ResponseEntity.ok(adminService.listarMatriculas());
    }

    @PostMapping("/matriculas")
    public ResponseEntity<MatriculaResponse> matricularAlumno(
            @Valid @RequestBody MatriculaRequest request
    ) {
        return ResponseEntity.ok(adminService.matricularAlumno(request));
    }
}
