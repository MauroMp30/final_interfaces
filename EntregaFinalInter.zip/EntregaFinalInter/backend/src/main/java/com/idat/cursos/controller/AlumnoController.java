package com.idat.cursos.controller;

import com.idat.cursos.dto.CursoResponse;
import com.idat.cursos.service.AlumnoService;
import java.security.Principal;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/alumno")
@PreAuthorize("hasRole('ESTUDIANTE')")
public class AlumnoController {

    private final AlumnoService alumnoService;

    public AlumnoController(AlumnoService alumnoService) {
        this.alumnoService = alumnoService;
    }

    @GetMapping("/mis-cursos")
    public ResponseEntity<List<CursoResponse>> misCursos(Principal principal) {
        return ResponseEntity.ok(alumnoService.listarMisCursos(principal.getName()));
    }
}
