# Sistema Académico - Spring Boot + Angular

Proyecto académico de gestión de cursos con autenticación JWT y control de acceso por roles.

## Tecnologías

### Backend
- Java
- Spring Boot 3
- Spring Security
- JWT
- Spring Data JPA / Hibernate
- MySQL
- Maven

### Frontend
- Angular 21
- TypeScript
- HttpClient
- Guards de rutas
- Interceptor JWT

## Roles del sistema

- **ADMIN**: administra usuarios, docentes, alumnos, cursos, secciones, asignaciones y matrículas.
- **DOCENTE**: consulta sus cursos, visualiza alumnos por curso, registra notas y consulta las notas del curso.
- **ESTUDIANTE**: consulta sus cursos y sus propias notas.

## Credenciales de prueba

El proyecto incluye un usuario administrador de prueba para facilitar la evaluación:

- Usuario: `admin`
- Contraseña: `123456`
- Rol: `ADMIN`


## Requisitos previos

- JDK 17 o compatible con la versión configurada en el proyecto
- Maven
- Node.js y npm
- Angular CLI
- MySQL Server

## Configuración de la base de datos

1. Crear la base de datos indicada en `application.properties`.
2. Configurar usuario y contraseña de MySQL en `src/main/resources/application.properties`.
3. Ejecutar el backend. Hibernate/JPA creará o actualizará las tablas según la configuración del proyecto.
4. El proyecto contiene inicialización de datos para disponer de roles y usuarios de prueba.

Si se desea usar el script SQL adicional, revisar `seed_admin.sql` y adaptar los nombres de tabla/columnas únicamente si el esquema local fuese diferente.

## Ejecución del backend

Desde la carpeta del backend:

```bash
mvn clean spring-boot:run
```

En Windows también puede utilizarse:

```bash
mvnw.cmd spring-boot:run
```

Backend disponible normalmente en:

`http://localhost:8080`

## Ejecución del frontend

Desde la carpeta del frontend:

```bash
npm install
ng serve
```

Frontend disponible en:

`http://localhost:4200`

## Autenticación

El login se realiza mediante:

`POST /api/auth/login`

El backend devuelve un token JWT. Angular lo almacena durante la sesión y el interceptor agrega automáticamente:

`Authorization: Bearer <token>`

Las rutas privadas están protegidas mediante guard de autenticación en Angular y autorización por roles en Spring Security.

## Rutas principales del frontend

### Autenticación
- `/login`

### Administrador
- `/admin`
- `/admin/usuarios`
- `/admin/docentes`
- `/admin/alumnos`
- `/admin/cursos`
- `/admin/secciones`
- `/admin/asignaciones`
- `/admin/matriculas`

### Docente
- `/docente`
- `/docente/curso/:idCurso`
- `/docente/curso/:idCurso/notas`
- `/docente/curso/:idCurso/alumno/:idAlumno/nota`

### Estudiante
- `/alumno`
- `/alumno/cursos`
- `/alumno/notas`

## Endpoints REST integrados

### Autenticación
- `POST /api/auth/login`

### Administración
- `GET /api/admin/usuarios`
- `POST /api/admin/usuarios`
- `GET /api/admin/docentes`
- `GET /api/admin/alumnos`
- `GET /api/admin/secciones`
- `GET /api/admin/asignaciones`
- `POST /api/admin/asignaciones`
- `GET /api/admin/matriculas`
- `POST /api/admin/matriculas`

### Cursos
- `GET /api/cursos`
- `POST /api/cursos`

### Docente
- `GET /api/docente/mis-cursos`
- `GET /api/docente/curso/{idCurso}/alumnos`

### Estudiante
- `GET /api/alumno/mis-cursos`

### Notas
- `POST /api/notas`
- `GET /api/notas/curso/{idCurso}`
- `GET /api/notas/mis-notas`

## Pruebas funcionales realizadas

Se verificaron manualmente los principales flujos:

1. Login con JWT por rol.
2. Acceso del ADMIN al dashboard.
3. Listado y búsqueda de usuarios.
4. Creación de usuarios ADMIN, DOCENTE y ESTUDIANTE.
5. Persistencia de usuarios en MySQL.
6. Listado de docentes y alumnos.
7. Listado y creación de cursos con sección seleccionada por nombre.
8. Listado de secciones.
9. Asignación de docente a curso usando selectores por nombre.
10. Matrícula de alumno en sección usando selectores por nombre.
11. Inicio de sesión de DOCENTE y visualización de sus cursos.
12. Visualización de alumnos matriculados por curso.
13. Registro de notas por el docente.
14. Consulta de notas del curso.
15. Inicio de sesión de ESTUDIANTE.
16. Consulta de cursos del estudiante.
17. Consulta de las notas del estudiante.
18. Cierre de sesión y navegación entre pantallas.



Antes de entregar, reemplazar esta línea por el enlace real del repositorio.


