-- ============================================================
-- DATOS DE PRUEBA - ADMINISTRADOR
-- Sistema Académico
-- ============================================================
-- IMPORTANTE:
-- El proyecto ya puede inicializar usuarios desde DataInitializer.
-- Este archivo se entrega como apoyo para la evaluación.
--
-- Credenciales esperadas para pruebas:
--   usuario: admin
--   password: 123456
--   rol: ADMIN
--
-- La contraseña de una aplicación con BCrypt NO debe guardarse
-- como texto plano. Por ese motivo se recomienda que el usuario
-- admin sea creado por DataInitializer usando PasswordEncoder.
-- ============================================================

-- 1) Comprobar que exista el rol ADMIN.
-- Ajustar nombres de columnas solo si el esquema local difiere.

INSERT INTO rol (nombre_rol)
SELECT 'ADMIN'
WHERE NOT EXISTS (
    SELECT 1 FROM rol WHERE nombre_rol = 'ADMIN'
);

-- 2) RECOMENDADO:
-- Ejecutar Spring Boot para que DataInitializer cree el usuario
-- con BCrypt correctamente.
--
-- Usuario: admin
-- Contraseña: 123456
--
-- No se inserta una contraseña en texto plano desde SQL para no
-- romper la autenticación BCrypt configurada en Spring Security.

-- Verificación:
SELECT id_rol, nombre_rol
FROM rol
WHERE nombre_rol = 'ADMIN';

SELECT id_usuario, username, nombre, apellido, email, estado
FROM usuario
WHERE username = 'admin';
